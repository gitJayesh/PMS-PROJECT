import { createContext } from "react";

const storyContext = createContext();

export default storyContext;
